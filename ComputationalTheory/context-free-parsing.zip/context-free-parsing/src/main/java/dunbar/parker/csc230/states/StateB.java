package dunbar.parker.csc230.states;

public class StateB implements State {

	public void change(char c) {
		// TODO Auto-generated method stub

	}

}
