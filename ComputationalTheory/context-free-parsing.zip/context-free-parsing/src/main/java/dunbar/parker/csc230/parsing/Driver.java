package dunbar.parker.csc230.parsing;

public class Driver {

	public static void main(String[] args) {
		Parser parser = new Parser();
		parser.run();
	}
}
