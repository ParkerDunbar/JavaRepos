package dunbar.parker.csc230.parsing;

import dunbar.parker.csc230.states.State;
import dunbar.parker.csc230.states.StateA;
import dunbar.parker.csc230.states.StateB;
import dunbar.parker.csc230.states.StateC;

public class Parser {
	private State state;
	private StateA stateA;
	private StateB stateB;
	private StateC stateC;
	
	public void run() {
		
	}
}
