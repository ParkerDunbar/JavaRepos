package dunbar.parker.csc230.states;

public class StateC implements State {

	public void change(char c) {
		// TODO Auto-generated method stub

	}

}
