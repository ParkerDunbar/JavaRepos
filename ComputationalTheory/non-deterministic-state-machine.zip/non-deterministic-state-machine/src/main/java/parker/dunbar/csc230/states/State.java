package parker.dunbar.csc230.states;

public interface State {
	void change(char c);
}
