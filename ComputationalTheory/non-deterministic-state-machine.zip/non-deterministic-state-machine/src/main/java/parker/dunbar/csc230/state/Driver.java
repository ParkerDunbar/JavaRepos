package parker.dunbar.csc230.state;

public class Driver {
	
	public static void main(String[] args) {
		StateMachine sm = new StateMachine();
		sm.run();
	}

}
