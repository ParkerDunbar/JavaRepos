package parker.dunbar.csc230.states;

import parker.dunbar.csc230.state.StateMachine;

public class StateJ implements State {

	private StateMachine sm;

	public StateJ(StateMachine sm) {
		this.setSm(sm);
	}

	public void change(char c) {

	}

	public StateMachine getSm() {
		return sm;
	}

	public void setSm(StateMachine sm) {
		this.sm = sm;
	}
}
