package dunbar.parker.csc230.turing;

public class Driver {

	public static void main(String[] args) {
		Turing turing = new Turing();
		turing.run();
	}

}
