package dunbar.parker.csc230.state;

import java.io.IOException;

public class Driver {

	public static void main(String[] args) throws IOException {
		StateMachine sm = new StateMachine();
		sm.run();
	}

}
