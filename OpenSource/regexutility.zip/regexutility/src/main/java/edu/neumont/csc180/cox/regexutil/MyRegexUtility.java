package edu.neumont.csc180.cox.regexutil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyRegexUtility implements RegexUtility {

	public boolean isValidHumanName(String name) {
		String regex = "[A-Z][a-z]+( [A-Z]\\.?)? [A-Z][a-z]+";
		return Pattern.matches(regex, name);
	}

	public boolean isValidEmailAddress(String email) {
		String regex = ".+@.+\\.[A-Z|a-z]{3}";
		return Pattern.matches(regex, email);
	}

	public boolean isValidPhoneNumber(String phone) {
		String regex = "([0-9]?[0-9]-)?[0-9]{3}-[0-9]{3}-[0-9]{4}";
		return Pattern.matches(regex, phone);
	}

	public boolean isValidSSN(String ssn) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isValidUSStreetAddress(String street) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean validatePasswordComplexity(String password, int minLength, int minUpper, int minLower,
			int minNumeric, int minSymbols) {
		// TODO Auto-generated method stub
		return false;
	}

	public int countContains(String needle, String haystack) {
		// TODO Auto-generated method stub
		return 0;
	}

	public String getHTMLTagContents(String html, String tagName) {
		String rawRegex = "<" + tagName + ">(.*)<\\/" + tagName + ">";
		Pattern p = Pattern.compile(rawRegex);
		Matcher m = p.matcher(html);
		
		if(m.find()) {
			for(int i = 0; i <= m.groupCount(); i++) {
				System.out.println("Group " + i + ": " + m.group(i));
			}
		}
		return m.group(1);
	}

	public String[] getHTMLTagsContents(String html, String tagName) {
		// TODO Auto-generated method stub
		return null;
	}

	public String[] getHTMLLinkURL(String html) {
		// TODO Auto-generated method stub
		return null;
	}

}
