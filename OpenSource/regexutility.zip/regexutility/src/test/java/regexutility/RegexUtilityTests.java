package regexutility;

import static org.junit.Assert.*;
import org.junit.Test;

import edu.neumont.csc180.cox.regexutil.MyRegexUtility;
import edu.neumont.csc180.cox.regexutil.RegexUtility;

public class RegexUtilityTests {

//	@Test
//	public void testValidFirstLast() {
//		RegexUtility r = new MyRegexUtility();
//		assertTrue(r.isValidHumanName("Ricky Ricardo"));
//	}
//	
//	@Test
//	public void testInvalidFirstOnly() {
//		RegexUtility r = new MyRegexUtility();
//		assertFalse(r.isValidHumanName("Madonna"));
//	}
	
	@Test
	public void testGetHtmlTagContents() {
		RegexUtility r = new MyRegexUtility();
		String boldContents =
		r.getHTMLTagContents("<html>This is <b>text<b>My text</b>more</b>more text <b>1</b>!</html>", "b");
		assertTrue(boldContents.equals("My text"));
	}

}
