package com.neufree.contacts.collections.tests;

import java.util.Random;

public class Test {

	public static void main(String[] args) {
		Random r = new Random();
		String alph = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		String num = "0123456789";
		int alphL = alph.length();
		int numL = num.length();
		
		for(int i = 0; i < 3000; i++) {
			String firstName = "", lastName = "", priEmail = "", secEmail = "", priPhone = "", secPhone = "";
			for(int j = 0; j < 5; j++) {
				firstName += alph.charAt(r.nextInt(alphL));
				lastName += alph.charAt(r.nextInt(alphL));
				priEmail += alph.charAt(r.nextInt(alphL));
				secEmail += alph.charAt(r.nextInt(alphL));
				priPhone += alph.charAt(r.nextInt(numL));
				secPhone += alph.charAt(r.nextInt(numL));
			}
			System.out.println(firstName);
		}
	}

}
