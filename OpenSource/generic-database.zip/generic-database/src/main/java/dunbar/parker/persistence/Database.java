package dunbar.parker.persistence;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;

public class Database<T extends Storable> {
	private RandomAccessFile file;
	
	private int nextOffset = 8;
	
	public Database(String path) throws IOException {
		boolean readOffsetFromFile = new File(path).exists();
		file = new RandomAccessFile(path, "rw");
		if(readOffsetFromFile) {
			nextOffset = file.readInt();
		}
	}
	
	public void insert(T obj) throws IOException {
		byte[] buffer = obj.serialize().getBytes();
		if(buffer.length != obj.serializedSize()) {
			throw new IllegalArgumentException("serialized size is not as promised");
		}
		file.seek(nextOffset);
		file.write(buffer);
		nextOffset += buffer.length;
		updateNextOffset();
	}
	
	public T lookup(int index) throws IOException {
		
		byte[] buffer = new byte[];
		int byteSeek = 8 + (index * 0);
		file.seek(byteSeek);
		file.readFully(buffer);
		return null;
		
		//T obj = new T;
		//c = c.deserialize(buffer);
		//return c.deserialize(buffer);
	}
	
	
//	public void remove(int i) {
//		for(int c = i; c < nextIndex - 1; c++) {
//			guts[c] = guts[c + 1];
//		}
//		nextIndex--;     
//	}
	
//	public T remove(int index) {
//		return null;
//	}
	
	private void updateNextOffset() throws IOException {
		int currentOffset = nextOffset;
		file.seek(0);
		file.writeInt(currentOffset);
	}
	
}
