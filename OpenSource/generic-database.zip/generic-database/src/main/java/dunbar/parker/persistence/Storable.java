package dunbar.parker.persistence;

public interface Storable {
	String serialize();
	
	void deserialize(String data);
	
	int serializedSize();
}
