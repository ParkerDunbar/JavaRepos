package dunbar.parker.csc180.bingo;

public class BingoDriver {

	public static void main(String[] args) throws InterruptedException {
		BingoCaller caller = new BingoCaller();
		caller.run();
	}

}
