package dunbar.parker.csc180.bingo;

public class BingoCard {

	
	public void createCard() {
	}
}
