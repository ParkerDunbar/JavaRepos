package dunbar.parker.csc360.utilities;

public class Section extends QuestionComponent {

}
