package dunbar.parker.csc360.utilities;

import java.io.IOException;

public interface FileReader {
	
	String read() throws IOException;
}
