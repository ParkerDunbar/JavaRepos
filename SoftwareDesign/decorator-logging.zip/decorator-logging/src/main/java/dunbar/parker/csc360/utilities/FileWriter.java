package dunbar.parker.csc360.utilities;

import java.io.IOException;

public interface FileWriter {

	void write(String data) throws IOException;
}
