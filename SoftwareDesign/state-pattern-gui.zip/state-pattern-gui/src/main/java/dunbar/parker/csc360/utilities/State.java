package dunbar.parker.csc360.utilities;

public interface State {
	void fireTimer();
}
