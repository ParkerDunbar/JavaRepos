package edu.neumont.csc110.d.monopoly;

import java.io.IOException;

public class RunGame {

	public static void main(String[] args) throws IOException {
		GamePlay game = new GamePlay();
		game.play();

	}

}
