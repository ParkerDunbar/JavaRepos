package edu.neumont.csc150.d.grocery;

public interface Items {
	double getWeight();
	double getPrice();

	
	
}
