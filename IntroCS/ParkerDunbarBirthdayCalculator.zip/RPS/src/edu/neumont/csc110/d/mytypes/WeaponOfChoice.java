package edu.neumont.csc110.d.mytypes;

public enum WeaponOfChoice {
	Rock,
	Paper,
	Scissors
}
