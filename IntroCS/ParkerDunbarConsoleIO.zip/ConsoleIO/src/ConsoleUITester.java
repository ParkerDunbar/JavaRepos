import java.io.IOException;

public class ConsoleUITester {

	public static void main(String[] args) throws IOException {
		//ConsoleUI.promptForMenuSelection(options, withQuit);
		//System.out.println(ConsoleUI.promptForBool("Yes or No?", "Yes", "No"));
		//System.out.println(ConsoleUI.promptForByte("Please enter a byte amount from -127 to 126 ", (byte) -128, (byte) 127));
		//System.out.println(ConsoleUI.promptForShort("Please enter a short amount from 1 to 1000", (short) 0, (short) 1001));
		//System.out.println(ConsoleUI.promptForInt("Please enter an integer amount from -3000 to 3000", -3001, 3001));
		//System.out.println(ConsoleUI.promptForLong("Please enter a long amount from  to ", min, max));
		//System.out.println(ConsoleUI.promptForFloat(prompt, min, max));
		//System.out.println(ConsoleUI.promptForDouble(prompt, min, max));
		//System.out.println(ConsoleUI.promptForInput(prompt, allowEmpty));
		//System.out.println(ConsoleUI.promptForChar(prompt, min, max));
		
	}

}
