package edu.neumont.csc150.airplace;

public enum Rank {
	SeniorCaptain,
	Captain,
	CoPilot,
	
}
