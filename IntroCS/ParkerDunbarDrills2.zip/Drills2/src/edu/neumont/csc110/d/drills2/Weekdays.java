package edu.neumont.csc110.d.drills2;

public enum Weekdays {
	Sunday,
	Monday,
	Tuesday,
	Wednesday,
	Thursday,
	Friday,
	Saturday
}
