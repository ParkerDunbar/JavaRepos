package edu.neumont.csc110.d.tictactoe;

public class Player {
	public char whoAmI;
}
