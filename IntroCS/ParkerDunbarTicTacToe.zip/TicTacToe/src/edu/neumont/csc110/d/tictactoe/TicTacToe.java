package edu.neumont.csc110.d.tictactoe;

import java.io.IOException;

public class TicTacToe {

	public static void main(String[] args) throws IOException {
		Game g = new Game();
		g.play();
		
	}

}
