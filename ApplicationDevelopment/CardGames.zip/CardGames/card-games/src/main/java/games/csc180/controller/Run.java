package games.csc180.controller;

import games.csc180.view.MainScreen;
import javafx.application.Application;

public class Run {

	public static void main(String[] args) {
		Application.launch(MainScreen.class);

	}

}
