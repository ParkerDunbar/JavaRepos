package junitTests;

import static org.junit.Assert.*;

import org.junit.Test;

import games.csc180.model.games.War;

public class TestWar {

	@Test
	public void playWarWorks() {
	}
}
