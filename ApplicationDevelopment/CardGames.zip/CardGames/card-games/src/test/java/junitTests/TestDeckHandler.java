package junitTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestDeckHandler {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
