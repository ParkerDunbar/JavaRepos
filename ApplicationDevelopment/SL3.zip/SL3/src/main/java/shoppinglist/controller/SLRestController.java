package shoppinglist.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import shoppinglist.model.ShoppingList;
import shoppinglist.model.repositories.SLJpaRepository;

@RestController
@RequestMapping("/lists")
public class SLRestController {

	/*
	 *lists/listid/item/itemid
	 */
	@Autowired
	private SLJpaRepository repo;
	
	
	@RequestMapping(path="", method=RequestMethod.POST)
	public Integer createList(
			@RequestBody ShoppingList list) {
		
		repo.saveAndFlush(list);
		return list.getId();
	}
	
	@RequestMapping(path="/{listId}", method=RequestMethod.DELETE)
	public void deleteList(
			@PathVariable Integer listId) {
		repo.delete(listId);
	}
	
	@RequestMapping(path="/{listId}", method=RequestMethod.PUT)
	public void updateList(
			@PathVariable Integer listId,
			@RequestBody ShoppingList updates) {
		
		ShoppingList existing = repo.findOne(listId);
		existing.setName(updates.getName());
		repo.saveAndFlush(existing);
	}
	
	@RequestMapping(path="/{listId}", method=RequestMethod.GET)
	public ShoppingList getList(
			@PathVariable Integer listId) {
		
		return repo.findOne(listId);
	}
	
	@RequestMapping(path="", method=RequestMethod.GET)
	public List<ShoppingList> getLists() {
		return repo.findAll();
	}
}













