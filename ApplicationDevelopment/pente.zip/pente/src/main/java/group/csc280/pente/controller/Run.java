package group.csc280.pente.controller;

import group.csc280.pente.model.Board;
import group.csc280.pente.view.MainView;

public class Run {

	public static void main(String[] args) {
		Pente game = new Pente();
		game.run();

	}

}
