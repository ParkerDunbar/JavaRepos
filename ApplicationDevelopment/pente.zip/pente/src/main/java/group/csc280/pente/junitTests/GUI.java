package group.csc280.pente.junitTests;

import static org.junit.Assert.*;

import org.junit.Test;

public class GUI {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
