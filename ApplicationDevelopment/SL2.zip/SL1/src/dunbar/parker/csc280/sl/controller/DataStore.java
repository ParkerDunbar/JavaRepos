package dunbar.parker.csc280.sl.controller;

import java.util.HashMap;
import java.util.Map;

import dunbar.parker.csc280.sl.model.User;

public class DataStore {
	public static Map<String, User> users = new HashMap<>();
}
