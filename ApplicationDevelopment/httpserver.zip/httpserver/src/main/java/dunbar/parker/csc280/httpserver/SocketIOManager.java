package dunbar.parker.csc280.httpserver;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

public class SocketIOManager {
	
	private String SL200 = "HTTP/1.0 200 OK\r\n";
	private String CT = "Content-type: text/html\r\n";
	private String CL = "Content-length: ";
	
	
	public Map<String, String> readHttpRequestHeaders(InputStream in) throws IOException {
		String rawHeaders = readToTerminalSymbol(in, "\r\n\r\n");
		Map<String, String> headers = new HashMap<>();
		String[] headersArray = rawHeaders.split("\r\n");
		for(String h : headersArray) {
			h = h.trim();
			System.out.println(h);
			String[] kvArr = h.split(":");
			if(kvArr.length == 2) {
				headers.put(kvArr[0].trim(), kvArr[1].trim());
			}
			else {
				headers.put("CMD", h);
			}
		}
		return headers;
	}
	
	public byte[] readHttpRequestBody(InputStream in) {
		return null;
	}
	
	public void writeHttpResponseHeaders(OutputStream out) {
		String headResponse = "";
		headResponse += SL200;
		
//		out.write();
	}
	
	public void writeHttpResponseBody(OutputStream out, byte[] bodyData) {
		
	}
	
	public String readToTerminalSymbol(InputStream in, String ts) throws IOException {
		int b;
		String readIn = "";
		while ((b = in.read()) != -1) {
			readIn += (char) b;
			if(readIn.endsWith(ts)) {
				break;
			}
		}
		return readIn;
	}
	
	public String readKnownLength(InputStream in, int size) {
		return null;
	}
}
