package group.csc130.nim.controller;

import group.csc130.nim.view.GameView;

public class Run {

	public static void main(String[] args) {
		MainGame game = new MainGame();
		game.run();
	}

}
