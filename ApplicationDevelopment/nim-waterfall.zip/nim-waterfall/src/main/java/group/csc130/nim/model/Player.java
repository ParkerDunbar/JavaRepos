package group.csc130.nim.model;

public class Player {

}
