package dunbar.parker.csc370.therapy;

import java.util.Timer;

public class Patient extends Thread {
	private static int MIN_TIME = 5000, MAX_TIME = 15000;
	private static Object therapist = new Object();
	
	
	public void run() {
		//Start wait time
		//Wait for therapist to free up
		//When free, end wait time start session time
		//End session time
		
		Timer t = new Timer();
		
		synchronized(therapist) {
			
		}
		
		System.out.println("Start Thread ID" + this.getId());

		try {
			Thread.sleep(Simulator.gen.nextInt((MAX_TIME - MIN_TIME + 1) + MIN_TIME));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		
		System.out.println("End Thread ID" + this.getId());
	}

}
