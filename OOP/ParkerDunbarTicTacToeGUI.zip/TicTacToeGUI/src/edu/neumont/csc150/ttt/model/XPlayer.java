package edu.neumont.csc150.ttt.model;

public class XPlayer extends Player {
	
	public XPlayer() {
		
	}
	public XPlayer(String whoAmI) {
		this.setWhoAmI(whoAmI);
	}
}
