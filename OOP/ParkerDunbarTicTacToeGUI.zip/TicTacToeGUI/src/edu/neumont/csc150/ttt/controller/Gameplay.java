package edu.neumont.csc150.ttt.controller;

import java.io.IOException;


import edu.neumont.csc150.ttt.model.OPlayer;
import edu.neumont.csc150.ttt.model.Player;
import edu.neumont.csc150.ttt.model.XPlayer;
import edu.neumont.csc150.ttt.view.DisplayGUI;

public class Gameplay {
	private static DisplayGUI gui = new DisplayGUI();

	public static Player xplayer = new XPlayer("X");
	public static Player oplayer = new OPlayer("O");
	public static Player whoseTurnIsIt;
	public int tie = 0;
	
	public void run() throws IOException {
		whoseTurnIsIt = oplayer;
		gui.GUIMain();
		
		
		
		/*ui.displayWelcomeMessage();
		while(!replay) {
			isQuit = false;
			board.initBoard();
			gui.GUIMain();
			whoseTurnIsIt = oplayer;
		
			while(!isQuit) {
				tie = 0;
				ui.printBoard();
				switchTurns();
				ui.displayPlayerTurn();
				takeSquare(ui.selectRow(), ui.selectCol());
				checkWin();
			}
		ui.displayWinner();
		replay = ui.promptForReset();
		}
		ui.displayGoodbyeMessage();
		
		//Initialize board
		//XPlayer selects square
		//Checks if square is available
		//Either takes square / Returns square is taken
		//Check win / tie condition
		//Change turn
		*/
	}
	

	/**
	 * checks to see if there is a winner or a tie
	 */
	public static void checkWin() {
		if(DisplayGUI.topLeft.getText() == "X" && DisplayGUI.topCenter.getText() == "X" && DisplayGUI.topRight.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.topLeft.getText() == "O" && DisplayGUI.topCenter.getText() == "O" && DisplayGUI.topRight.getText() == "O") {
			gui.displayPlayerOWin();
		}
		if(DisplayGUI.midLeft.getText() == "X" && DisplayGUI.midCenter.getText() == "X" && DisplayGUI.midRight.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.midLeft.getText() == "O" && DisplayGUI.midCenter.getText() == "O" && DisplayGUI.midRight.getText() == "O") {
			gui.displayPlayerOWin();
		}
		if(DisplayGUI.botLeft.getText() == "X" && DisplayGUI.botCenter.getText() == "X" && DisplayGUI.botRight.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.botLeft.getText() == "O" && DisplayGUI.botCenter.getText() == "O" && DisplayGUI.botRight.getText() == "O") {
			gui.displayPlayerOWin();
		}
		
		
		
		if(DisplayGUI.topLeft.getText() == "X" && DisplayGUI.midLeft.getText() == "X" && DisplayGUI.botLeft.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.topLeft.getText() == "O" && DisplayGUI.midLeft.getText() == "O" && DisplayGUI.botLeft.getText() == "O") {
			gui.displayPlayerOWin();
		}
		if(DisplayGUI.topCenter.getText() == "X" && DisplayGUI.midCenter.getText() == "X" && DisplayGUI.botCenter.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.topCenter.getText() == "O" && DisplayGUI.midCenter.getText() == "O" && DisplayGUI.botCenter.getText() == "O") {
			gui.displayPlayerOWin();
		}
		if(DisplayGUI.topRight.getText() == "X" && DisplayGUI.midRight.getText() == "X" && DisplayGUI.botRight.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.topRight.getText() == "O" && DisplayGUI.midRight.getText() == "O" && DisplayGUI.botRight.getText() == "O") {
			gui.displayPlayerOWin();
		}
		
		
		
		if(DisplayGUI.topLeft.getText() == "X" && DisplayGUI.midCenter.getText() == "X" && DisplayGUI.botRight.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.topLeft.getText() == "O" && DisplayGUI.midCenter.getText() == "O" && DisplayGUI.botRight.getText() == "O") {
			gui.displayPlayerOWin();
		}
		if(DisplayGUI.topRight.getText() == "X" && DisplayGUI.midCenter.getText() == "X" && DisplayGUI.botLeft.getText() == "X") {
			gui.displayPlayerXWin();
		}
		else if(DisplayGUI.topRight.getText() == "O" && DisplayGUI.midCenter.getText() == "O" && DisplayGUI.botLeft.getText() == "O") {
			gui.displayPlayerOWin();
		}
		
		
		
		
		
	}


	/**
	 * @param takes in the requested square takes it based on current player
	 * checks to see if square is already taken, reprompts if it is
	 **/
	/*private void takeSquare(int i, int j) throws IOException {
		if(getBoard().square[i][j].isAvailable()) {
			getBoard().square[i][j].setAvailable(false);
			getBoard().square[i][j].setPlayer(whoseTurnIsIt);

		}
		else {
			ui.displaySpaceTaken();
			takeSquare(ui.selectRow(), ui.selectCol());
		}
		
		
	}*/


	/**
	 * switches the turn of the players
	 */
	/*private void switchTurns() {
		if(whoseTurnIsIt == xplayer) {
			whoseTurnIsIt = oplayer;
		}
		else if(whoseTurnIsIt == oplayer) {
			whoseTurnIsIt = xplayer;
		}
		
	}*/
	
	/**
	 * 
	 * @return the current board
	 */
	/*public static Board getBoard() {
		return board;
	}*/
	
	
}
