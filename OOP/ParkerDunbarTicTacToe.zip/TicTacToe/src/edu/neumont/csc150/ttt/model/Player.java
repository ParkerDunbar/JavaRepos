package edu.neumont.csc150.ttt.model;

public abstract class Player {
	private String whoAmI;

	/**
	 * @return the whoAmI
	 */
	public String getWhoAmI() {
		return whoAmI;
	}

	/**
	 * @param whoAmI the whoAmI to set
	 */
	public void setWhoAmI(String whoAmI) {
		this.whoAmI = whoAmI;
	}



}
