package edu.neumont.csc150.ttt.model;

public class OPlayer extends Player {
	
	public OPlayer() {
		
	}
	public OPlayer(String whoAmI) {
		this.setWhoAmI(whoAmI);
	}

}
