package edu.neumont.csc150.ttt;

import java.io.IOException;

import edu.neumont.csc150.ttt.controller.Gameplay;

public class Run {

	public static void main(String[] args) throws IOException {
		Gameplay play = new Gameplay();
		play.run();
		

	}

}
